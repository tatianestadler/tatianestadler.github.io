// Exemplo: mensagem no console ao carregar o site
document.addEventListener("DOMContentLoaded", () => {
  console.log("Site da UBS carregado com sucesso!");
});